/*
    Copyright (c) 2005-2021 Intel Corporation

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#ifndef __TBB_parallel_sort_H
#define __TBB_parallel_sort_H

#include "detail/_namespace_injection.h"
#include "parallel_for.h"
#include "blocked_range.h"
#include "profiling.h"

#include <algorithm>
#include <iterator>
#include <functional>
#include <cstddef>

namespace tbb {
namespace detail {
#if __TBB_CPP20_CONCEPTS_PRESENT
inline namespace d0 {

// TODO: consider using std::strict_weak_order concept
template <typename Compare, typename Iterator>
concept compare = requires( const std::remove_reference_t<Compare>& comp, typename std::iterator_traits<Iterator>::reference value ) {
    // Forward via iterator_traits::reference
    { comp(typename std::iterator_traits<Iterator>::reference(value),
           typename std::iterator_traits<Iterator>::reference(value)) } -> std::convertible_to<bool>;
};

// Inspired by std::__PartiallyOrderedWith exposition only concept
template <typename T>
concept less_than_comparable = requires( const std::remove_reference_t<T>& lhs,
                                         const std::remove_reference_t<T>& rhs ) {
    { lhs < rhs } -> boolean_testable;
};

} // namespace d0
#endif // __TBB_CPP20_CONCEPTS_PRESENT
namespace d1 {

//! Range used in quicksort to split elements into subranges based on a value.
/** The split operation selects a splitter and places all elements less than or equal
    to the value in the first range and the remaining elements in the second range.
    @ingroup algorithms */
template<typename RandomAccessIterator, typename Compare>
class quick_sort_range {
    std::size_t median_of_three( const RandomAccessIterator& array, std::size_t l, std::size_t m, std::size_t r ) const {
        return comp(array[l], array[m]) ? ( comp(array[m], array[r]) ? m : ( comp(array[l], array[r]) ? r : l ) )
                                        : ( comp(array[r], array[m]) ? m : ( comp(array[r], array[l]) ? r : l ) );
    }

    std::size_t pseudo_median_of_nine( const RandomAccessIterator& array, const quick_sort_range& range ) const {
        std::size_t offset = range.size / 8u;
        return median_of_three(array,
                               median_of_three(array, 0 , offset, offset * 2),
                               median_of_three(array, offset * 3, offset * 4, offset * 5),
                               median_of_three(array, offset * 6, offset * 7, range.size - 1));

    }

    std::size_t split_range( quick_sort_range& range ) {
        RandomAccessIterator array = range.begin;
        RandomAccessIterator first_element = range.begin;
        std::size_t m = pseudo_median_of_nine(array, range);
        if( m != 0 ) std::iter_swap(array, array + m);

        std::size_t i = 0;
        std::size_t j = range.size;
        // Partition interval [i + 1,j - 1] with key *first_element.
        for(;;) {
            __TBB_ASSERT( i < j, nullptr );
            // Loop must terminate since array[l] == *first_element.
            do {
                --j;
                __TBB_ASSERT( i <= j, "bad ordering relation?" );
            } while( comp(*first_element, array[j]) );
            do {
                __TBB_ASSERT( i <= j, nullptr );
                if( i == j ) goto partition;
                ++i;
            } while( comp(array[i], *first_element) );
            if( i == j ) goto partition;
            std::iter_swap(array + i, array + j);
        }
partition:
        // Put the partition key were it belongs
        std::iter_swap(array + j, first_element);
        // array[l..j) is less or equal to key.
        // array(j..r) is greater or equal to key.
        // array[j] is equal to key
        i = j + 1;
        std::size_t new_range_size = range.size - i;
        range.size = j;
        return new_range_size;
    }

public:
    quick_sort_range() = default;
    quick_sort_range( const quick_sort_range& ) = default;
    void operator=( const quick_sort_range& ) = delete;

    static constexpr std::size_t grainsize = 500;
    const Compare& comp;
    std::size_t size;
    RandomAccessIterator begin;

    quick_sort_range( RandomAccessIterator begin_, std::size_t size_, const Compare& comp_ ) :
        comp(comp_), size(size_), begin(begin_) {}

    bool empty() const { return size == 0; }
    bool is_divisible() const { return size >= grainsize; }

    quick_sort_range( quick_sort_range& range, split )
        : comp(range.comp)
        , size(split_range(range))
          // +1 accounts for the pivot element, which is at its correct place
          // already and, therefore, is not included into subranges.
        , begin(range.begin + range.size + 1) {}
};

//! Body class used to test if elements in a range are presorted
/** @ingroup algorithms */
template<typename RandomAccessIterator, typename Compare>
class quick_sort_pretest_body {
    const Compare& comp;
    task_group_context& context;

public:
    quick_sort_pretest_body() = default;
    quick_sort_pretest_body( const quick_sort_pretest_body& ) = default;
    void operator=( const quick_sort_pretest_body& ) = delete;

    quick_sort_pretest_body( const Compare& _comp, task_group_context& _context ) : comp(_comp), context(_context) {}

    void operator()( const blocked_range<RandomAccessIterator>& range ) const {
        RandomAccessIterator my_end = range.end();

        int i = 0;
        //TODO: consider using std::is_sorted() for each 64 iterations (requires performance measurements)
        for( RandomAccessIterator k = range.begin(); k != my_end; ++k, ++i ) {
            if( i % 64 == 0 && context.is_group_execution_cancelled() ) break;

            // The k - 1 is never out-of-range because the first chunk starts at begin+serial_cutoff+1
            if( comp(*(k), *(k - 1)) ) {
                context.cancel_group_execution();
                break;
            }
        }
    }
};

//! Body class used to sort elements in a range that is smaller than the grainsize.
/** @ingroup algorithms */
template<typename RandomAccessIterator, typename Compare>
struct quick_sort_body {
    void operator()( const quick_sort_range<RandomAccessIterator,Compare>& range ) const {
        std::sort(range.begin, range.begin + range.size, range.comp);
    }
};

//! Method to perform parallel_for based quick sort.
/** @ingroup algorithms */
template<typename RandomAccessIterator, typename Compare>
void do_parallel_quick_sort( RandomAccessIterator begin, RandomAccessIterator end, const Compare& comp ) {
    parallel_for(quick_sort_range<RandomAccessIterator,Compare>(begin, end - begin, comp),
                 quick_sort_body<RandomAccessIterator,Compare>(),
                 auto_partitioner());
}

//! Wrapper method to initiate the sort by calling parallel_for.
/** @ingroup algorithms */
template<typename RandomAccessIterator, typename Compare>
void parallel_quick_sort( RandomAccessIterator begin, RandomAccessIterator end, const Compare& comp ) {
    task_group_context my_context(PARALLEL_SORT);
    constexpr int serial_cutoff = 9;

    __TBB_ASSERT( begin + serial_cutoff < end, "min_parallel_size is smaller than serial cutoff?" );
    RandomAccessIterator k = begin;
    for( ; k != begin + serial_cutoff; ++k ) {
        if( comp(*(k + 1), *k) ) {
            do_parallel_quick_sort(begin, end, comp);
            return;
        }
    }

    // Check is input range already sorted
    parallel_for(blocked_range<RandomAccessIterator>(k + 1, end),
                 quick_sort_pretest_body<RandomAccessIterator, Compare>(comp, my_context),
                 auto_partitioner(),
                 my_context);

    if( my_context.is_group_execution_cancelled() )
        do_parallel_quick_sort(begin, end, comp);
}

/** \page parallel_sort_iter_req Requirements on iterators for parallel_sort
    Requirements on the iterator type \c It and its value type \c T for \c parallel_sort:

    - \code void iter_swap( It a, It b ) \endcode Swaps the values of the elements the given
    iterators \c a and \c b are pointing to. \c It should be a random access iterator.

    - \code bool Compare::operator()( const T& x, const T& y ) \endcode True if x comes before y;
**/

/** \name parallel_sort
    See also requirements on \ref parallel_sort_iter_req "iterators for parallel_sort". **/
//@{

#if __TBB_CPP20_CONCEPTS_PRESENT
template<typename It>
using iter_value_type = typename std::iterator_traits<It>::value_type;

template<typename Range>
using range_value_type = typename std::iterator_traits<range_iterator_type<Range>>::value_type;
#endif

//! Sorts the data in [begin,end) using the given comparator
/** The compare function object is used for all comparisons between elements during sorting.
    The compare object must define a bool operator() function.
    @ingroup algorithms **/
template<typename RandomAccessIterator, typename Compare>
    __TBB_requires(std::random_access_iterator<RandomAccessIterator> &&
                   compare<Compare, RandomAccessIterator> &&
                   std::movable<iter_value_type<RandomAccessIterator>>)
void parallel_sort( RandomAccessIterator begin, RandomAccessIterator end, const Compare& comp ) {
    constexpr int min_parallel_size = 500;
    if( end > begin ) {
        if( end - begin < min_parallel_size ) {
            std::sort(begin, end, comp);
        } else {
            parallel_quick_sort(begin, end, comp);
        }
    }
}

//! Sorts the data in [begin,end) with a default comparator \c std::less
/** @ingroup algorithms **/
template<typename RandomAccessIterator>
    __TBB_requires(std::random_access_iterator<RandomAccessIterator> &&
                   less_than_comparable<iter_value_type<RandomAccessIterator>> &&
                   std::movable<iter_value_type<RandomAccessIterator>>)
void parallel_sort( RandomAccessIterator begin, RandomAccessIterator end ) {
    parallel_sort(begin, end, std::less<typename std::iterator_traits<RandomAccessIterator>::value_type>());
}

//! Sorts the data in rng using the given comparator
/** @ingroup algorithms **/
template<typename Range, typename Compare>
    __TBB_requires(container_based_sequence<Range, std::random_access_iterator_tag> &&
                   compare<Compare, range_iterator_type<Range>> &&
                   std::movable<range_value_type<Range>>)
void parallel_sort( Range&& rng, const Compare& comp ) {
    parallel_sort(std::begin(rng), std::end(rng), comp);
}

//! Sorts the data in rng with a default comparator \c std::less
/** @ingroup algorithms **/
template<typename Range>
    __TBB_requires(container_based_sequence<Range, std::random_access_iterator_tag> &&
                   less_than_comparable<range_value_type<Range>> &&
                   std::movable<range_value_type<Range>>)
void parallel_sort( Range&& rng ) {
    parallel_sort(std::begin(rng), std::end(rng));
}
//@}

} // namespace d1
} // namespace detail

inline namespace v1 {
    using detail::d1::parallel_sort;
} // namespace v1
} // namespace tbb

#endif /*__TBB_parallel_sort_H*/
