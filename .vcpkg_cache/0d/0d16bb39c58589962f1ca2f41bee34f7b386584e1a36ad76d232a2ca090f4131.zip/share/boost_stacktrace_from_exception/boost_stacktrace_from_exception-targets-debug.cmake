#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debug".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Boost::stacktrace_from_exception" for configuration "Debug"
set_property(TARGET Boost::stacktrace_from_exception APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBUG)
set_target_properties(Boost::stacktrace_from_exception PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_DEBUG "CXX"
  IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/debug/lib/boost_stacktrace_from_exception-vc143-mt-gd-x64-1_88.lib"
  )

list(APPEND _cmake_import_check_targets Boost::stacktrace_from_exception )
list(APPEND _cmake_import_check_files_for_Boost::stacktrace_from_exception "${_IMPORT_PREFIX}/debug/lib/boost_stacktrace_from_exception-vc143-mt-gd-x64-1_88.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
